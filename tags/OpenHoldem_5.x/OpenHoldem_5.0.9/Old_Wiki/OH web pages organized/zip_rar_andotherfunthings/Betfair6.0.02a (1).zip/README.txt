Betfair 9 Player Table Map

------------------------------------------------
INSTRUCTIONS
------------------------------------------------

1. Make sure that you have the newest version of the Betfair Poker software.
2. Launch the Betfair Poker - "Fixed Size" mode instead of Betfair Poker mode
   in which you can stretch the windows. (Got it? Launch the NON streatchable
   mode!) If you can't do that for some reason, you are screwed.
3. Make sure that the 4 color deck and Show Hand Strength modes are OFF.
4. MINIMIZE the "CONTROL PANEL" window totally so that even the
   "Autopost Blinds" and "Sit Out Next Hand" checkboxes are invisible.
   Othervise OH won't be able to read player3's bet.
